# Distinguished

A dark vim color scheme for 256-color terminals.
