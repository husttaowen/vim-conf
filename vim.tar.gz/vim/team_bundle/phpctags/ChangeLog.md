Version 0.5.1
-------------

* Fix building compatiblity with PHP 5.3.*
  thanks to grep-awesome@github

Version 0.5
-----------

* Add trait support
  thanks to Mark Wu
* Add inherits support
  thanks to Mark Wu
* Add namespace support
  thanks to Mark Wu
* Add instruction to enable phar extension in README

Version 0.4.2
-------------

* Add assign reference support to phpctags
  thanks to Mark Wu

Version 0.4.1
-------------

* Add explaination for PHAR supported platforms

Version 0.4
-----------

* add tagline support
  thanks to Mark Wu
* add a Makefile to build stand-alone PHAR executable
  thanks to Mark Wu
* update PHPParser dependency to version 0.9.3

Version 0.3
-----------

* able to control the memroy size to be used
  thanks to Dannel Jurado
* improved command line compatiblity to ctags
  thanks to Sander Marechal
* bug fixes: #5 and #7

Version 0.2
-----------

* new kind descriptor
* ctags flags support
    * excmd
    * fields
    * format
* new test case layer
* introduce debug mode
* bug fixes: #3 and #4

Version 0.1
-----------

* ctags compatible
* surppoted tokens
    * constant
    * variable
    * function
    * class
    * class method
    * class property
    * class constant
    * interface
* scope field support
* access field support
