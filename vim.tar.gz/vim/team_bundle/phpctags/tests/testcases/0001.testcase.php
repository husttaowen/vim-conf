<?php
class t_0001 extends PHPCtagsTestCase {

    public function __construct()
    {
        parent::__construct();
        $this->mExample = '0001';
    }

}
