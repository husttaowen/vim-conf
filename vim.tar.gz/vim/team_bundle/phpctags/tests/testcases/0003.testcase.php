<?php
class t_0003 extends PHPCtagsTestCase {

    public function __construct()
    {
        parent::__construct();
        $this->mExample = '0003';
    }

}
