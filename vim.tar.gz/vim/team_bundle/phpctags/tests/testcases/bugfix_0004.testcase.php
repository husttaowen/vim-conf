<?php
class t_bugfix_0004 extends PHPCtagsTestCase {

    public function __construct()
    {
        parent::__construct();
        $this->mExample = 'bugfix_0004';
    }

}
