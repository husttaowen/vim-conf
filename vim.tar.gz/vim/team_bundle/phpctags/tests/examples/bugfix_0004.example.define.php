<?php
function e_bugfix_0004_define()
{
    return array(
        array(
            'name'=>'Foo',
            'kind'=>'c',
            'line'=>'4',
            'scope'=>'',
            'access'=>'',
        ),
    );
}
