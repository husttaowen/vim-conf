<?php
function e_bugfix_0007_define()
{
    return array(
        array(
            'name'=>'MyClass',
            'kind'=>'c',
            'line'=>'3',
            'scope'=>'',
            'access'=>'',
        ),
    );
}
