<?php
function e_bugfix_0003_define()
{
    return array(
        array(
            'name'=>'DbConnectionUserDecorator',
            'kind'=>'c',
            'line'=>'2',
            'scope'=>'',
            'access'=>'',
        ),
        array(
            'name'=>'__set',
            'kind'=>'m',
            'line'=>'3',
            'scope'=>'class:DbConnectionUserDecorator',
            'access'=>'public',
        ),
    );
}
