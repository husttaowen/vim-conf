<?php
namespace Bar;

class Foo {
}
