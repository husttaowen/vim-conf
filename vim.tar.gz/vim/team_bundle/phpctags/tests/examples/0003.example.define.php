<?php
function e_0003_define()
{
    return array(
        array(
            'name'=>'ctags',
            'kind'=>'v',
            'line'=>'3',
            'scope'=>'',
            'access'=>'',
        ),
        array(
            'name'=>'result',
            'kind'=>'v',
            'line'=>'4',
            'scope'=>'',
            'access'=>'',
        ),
    );
}
