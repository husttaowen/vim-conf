<?php
if (!class_exists('MyClass')) {
    class MyClass {
    }
}
