# Contributors #

SnipMate was originally authored by Michael Sanders
([Vim](http://www.vim.org/account/profile.php?user_id=16544),
[GitHub](https://github.com/msanders)).

It is currently maintained by [Rok Garbas](rok@garbas.si), [Marc
Weber](marco-oweber@gmx.de), and [Adnan Zafar](https://github.com/ajzafar) with
additional contributions from:

* [907th](https://github.com/907th)
* [adkron](https://github.com/adkron)
* [alderz](https://github.com/alderz)
* [asymmetric](https://github.com/asymmetric)
* [bpugh](https://github.com/bpugh)
* [bruno-](https://github.com/bruno-)
* [darkwise](https://github.com/darkwise)
* [fish-face](https://github.com/fish-face)
* [henrik](https://github.com/henrik)
* [holizz](https://github.com/holizz)
* [honza](https://github.com/honza)
* [hpesoj](https://github.com/hpesoj)
* [ironcamel](https://github.com/ironcamel)
* [jb55](https://github.com/jb55)
* [jbernard](https://github.com/jbernard)
* [jherdman](https://github.com/jherdman)
* [kozo2](https://github.com/kozo2)
* [lilydjwg](https://github.com/lilydjwg)
* [marutanm](https://github.com/marutanm)
* [MicahElliott](https://github.com/MicahElliott)
* [muffinresearch](https://github.com/muffinresearch)
* [pielgrzym](https://github.com/pielgrzym)
* [pose](https://github.com/pose)
* [r00k](https://github.com/r00k)
* [radicalbit](https://github.com/radicalbit)
* [redpill](https://github.com/redpill)
* [robhudson](https://github.com/robhudson)
* [Shraymonks](https://github.com/shraymonks)
* [sickill](https://github.com/sickill)
* [statik](https://github.com/statik)
* [steveno](https://github.com/steveno)
* [taq](https://github.com/taq)
* [thisgeek](https://github.com/thisgeek)
* [Xandaros](https://github.com/Xandaros)
