<?php

class Foo extends \NS1\Foo {

    public function bar()
    {
        $this->
    }

}
