<?php

$foo_only_in_tags->
// TODO
$foo_only_in_tags::
