<?php

class FooClass {
}

class BarClass {
}

interface BarInterface {
}
